<?php
// Heading
$_['heading_title']    = '<font color = "#1e91cf"><b>Size Chart</b></font>'; 
$_['site_title']       = 'Size Chart';

// Text
$_['text_module']      = 'Modules';
$_['text_success']     = 'Success: You have modified Size Chart module!';
$_['text_edit']        = 'Size Chart Template List';

// Entry
$_['entry_limit']      = 'Limit';
$_['entry_image']      = 'Image (W x H) and Resize Type';
$_['entry_width']      = 'Width';
$_['entry_height']     = 'Height';
$_['entry_status']     = 'Status';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify Size Chart module!';
$_['error_image']      = 'Image width &amp; height dimensions required!';