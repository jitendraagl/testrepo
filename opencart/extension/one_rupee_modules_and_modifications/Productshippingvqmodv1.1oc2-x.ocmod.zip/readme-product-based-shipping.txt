This extension helps you define shipping price on product basis. Now you can define shipping per product basis easily. After installation of this extension, you will see a new entry field on Product detail page under "Data" tab. Enter the shipping price for the selected product and save. 


You can use this extension in parallel with any other shipping extension, you already using.

Note: This extension purchased in only to be used for single server/cart. Please respect copyrights. :)

==============Change Log========================

This is created using OC modification system, so no file will be replaced.

one change in DataBase
------------------------------------------------

The table "product" will have a new column "Shipping_price". The column is created automatically when you install the extension.


==============[b]Installation notes OC ver 2.0[/b]=================

For installation, in the admin area, Please browse the navigation "Extension->Extension Installer". here click the "upload" button and select the downloaded extension zip/compressed file from your system. Once the file is selected, press the button "continue". Extension is installed. After the installation, perform following steps for usage.
==============[b]Installation notes OC ver 1.5.x[/b]=================
For OC 1.5.x, it requires vqMod. First install the vqMod which is free extension. After that, upload the extension folder to the installation directory of Opencart. no core file will be modified and extension will be installed. After the installation, perform following steps for usage.

==============[b]Usage Method[/b]=================
Go to Extensions->Shipping
Click on the "install" button next to "product base shipping" row. 
It will get installed. Press "edit" link and change the setting to your need.
Go to product details by navigation "Catalog->Products" and under "Data" tab, specify the shipping price in the "shipping cost" entry field.
For any queries/bug report or installation request, please email at asif.mahmood@gmail.com 
Installation for single server will be charged only @ $25.

This is specifically for OC version 2.x. If you need to install on earlier version like (1.5.x) then please download the other installation file from the download options.

