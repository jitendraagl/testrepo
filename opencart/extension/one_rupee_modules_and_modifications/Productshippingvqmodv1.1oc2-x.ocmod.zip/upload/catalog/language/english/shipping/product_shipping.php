<?php
// Text
$_['text_title']       = 'Shipping per Product';
$_['text_description'] = 'Per Item Shipping Rate';
