<?php
/**
 * @extension-payment	GOP_COD
 * @author-name			Michail Gkasios
 * @copyright			Copyright (C) 2013 GKASIOS
 * @license				GNU/GPL, see http://www.gnu.org/licenses/old-licenses/gpl-2.0.txt
 */

// Text
$_['text_title']		=	'Cash On Delivery';
$_['text_without_taxes']=	'without taxes';
$_['text_free']			=	'Free';
?>