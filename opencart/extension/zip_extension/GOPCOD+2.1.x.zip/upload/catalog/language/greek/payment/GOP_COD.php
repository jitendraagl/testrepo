<?php
/**
 * @extension-payment	GOP_COD
 * @author-name			Michail Gkasios
 * @copyright			Copyright (C) 2013 GKASIOS
 * @license				GNU/GPL, see http://www.gnu.org/licenses/old-licenses/gpl-2.0.txt
 */

// Text
$_['text_title']		=	'Αντικαταβολή';
$_['text_without_taxes']=	'χωρίς φόρους';
$_['text_free']			=	'Δωρεάν';
?>