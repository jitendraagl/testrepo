=======================================================
======================= Documnetation =================
=======================================================

Size chart
Developer	: vikasgarg40
E-mail		: contact@onjection.com

Website		: http://www.onjection.com


=======================================================
======================= INSTALLATION STEPS ============
=======================================================

	1. Go to admin->Extensions->Extension Installer. 
	2. Click on Upload button and select the zip you just downloaded.
	3. After the progess bar has been completed with the success message underneath it; go to admin->Extensions->Modifications and click on refresh.
	4. If there is any error occured during the installation  then download the extension and follow the steps written on it:

		http://www.opencart.com/index.php?route=extension/extension/info&extension_id=18892
	
	Then follow again from step 1.
	
	5. Go to admin->Modules and then install Size Chart Module in that. 
	6. To add Size Chart-: Click on Insert, give the columns.
	7. Fill the products or cstegory on which you have to show the size chart.

=======================================================
======================= FEEDBACK ======================
=======================================================

Thanks for your purchase. 
In case of any doubt or any suggestion Dont be shy, get in touch. Send us an email at contact@onjection.com

Your feedback and reviews are welcome & gratefully received. 

Thanks, 
ONjection Solutions