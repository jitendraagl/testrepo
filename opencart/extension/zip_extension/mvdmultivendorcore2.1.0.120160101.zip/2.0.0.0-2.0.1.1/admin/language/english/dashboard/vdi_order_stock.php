<?php
// Heading
$_['heading_title']                = 'Recent Order & Stock Status';

// Text
$_['text_new_order_product']    = ' was added to new Order ID <a href="order_id=%s">%s</a>.';
$_['text_low_stock_product']    = '<i class="fa fa-exclamation-triangle" style="color:red"></i> <a href="product_id=%s">%s</a> at low stock <span class="label label-danger">%s</span> state.';

?>