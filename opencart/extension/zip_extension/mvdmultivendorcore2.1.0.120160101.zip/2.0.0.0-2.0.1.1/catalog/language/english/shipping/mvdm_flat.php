<?php
// Text
$_['text_title']       = 'Multi Vendor / DropShipper Multiple Flat Rate';
$_['text_weight'] 	   = 'Weight:';
?>