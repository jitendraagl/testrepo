Version for 2.0.x
It uses gd for colorizing the images.

Instructions:
1. if you have ftp configured on admin:
Go to extensions->Extension installer
Upload the image_colored_product.ocmod.zip file
Go to extensions->Modifications 
Click clear button and then click refresh button
Thats all

2. if you have no ftp configured on admin:
Upload by ftp then content of upload folder to your root opencart folder
Go to extensions->Extension installer
Upload the image_colored_product.ocmod.xml file
Go to extensions->Modifications 
Click clear button and then click refresh button
Thats all